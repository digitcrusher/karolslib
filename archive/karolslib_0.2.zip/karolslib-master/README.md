# karolslib
My universal library.

Compile with make.

"check" runs perl to find and replace 4 whitespaces with a tab.

For linux: Required linker parameters: "-L/usr/lib/X11R6/lib -lX11".

For windows: Required linker parameters: "-mwindows -pthread -lgdi32".
Required shared library "pthreadGC-3.dll" can be found in "build" folder.
